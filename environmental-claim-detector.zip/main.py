from src.config import Config
from src.data_processor import DataProcessor
from src.model import EnvironmentalClaimClassifier
from src.evaluate import Evaluator
import pytorch_lightning as pl
import torch
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def train_and_evaluate(config: Config):
    pl.seed_everything(config.SEED, workers=True)
    processor = DataProcessor(config)
    train_ds, val_ds = processor.prepare_datasets()
    train_loader, val_loader = processor.create_dataloaders(train_ds, val_ds)
    class_weights = processor.calculate_class_weights(train_ds)
    logger.info(f"Class weights: {class_weights}")

    early_stopping = pl.callbacks.EarlyStopping(
        monitor=config.EARLY_STOP_METRIC,
        mode=config.EARLY_STOP_MODE,
        patience=config.EARLY_STOP_PATIENCE,
        verbose=False
    )

    trainer = pl.Trainer(
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        devices=1,
        max_epochs=config.MAX_EPOCHS,
        deterministic=True,
        log_every_n_steps=config.LOG_EVERY_N_STEPS,
        callbacks=[early_stopping],
        enable_checkpointing=False,
    )

    results = []
    confusion_matrices = []

    for i, hp_config in enumerate(config.HYPERPARAMETER_CONFIGS):
        logger.info(f"\n▶️  Run {i}: {hp_config}")
        model = EnvironmentalClaimClassifier(
            model_name=config.MODEL_NAME,
            class_weights=class_weights,
            **hp_config
        )
        trainer.fit(model, train_loader, val_loader)
        eval_results = Evaluator.evaluate_model(model, val_loader)
        results.append({**hp_config, "acc": eval_results["acc"], "f1": eval_results["f1"]})
        confusion_matrices.append(eval_results["cm"])
        print(eval_results["report"])

    results_df = pd.DataFrame(results)
    best_idx = results_df.f1.idxmax()
    best_config = results[best_idx]
    best_cm = confusion_matrices[best_idx]

    print("\n=== Results Summary ===")
    print(results_df)
    print(f"\nBest run: {best_config}")
    Evaluator.plot_results(results_df, best_cm)

    return {"results_df": results_df, "best_config": best_config, "best_confusion_matrix": best_cm}

if __name__ == "__main__":
    config = Config()
    results = train_and_evaluate(config)
